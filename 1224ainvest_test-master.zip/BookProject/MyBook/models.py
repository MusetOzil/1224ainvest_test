from django.db import models
from datetime import datetime


# Create your models here.



class BookDetails(models.Model):
    STATE = (
        (1, '连载'),
        (2, '完结'),
    )
    name = models.CharField(max_length=128, null=False, verbose_name='名称')
    introduce = models.CharField(max_length=256, null=False, verbose_name='分类介绍')
    author = models.CharField(max_length=128, null=False,verbose_name='作者')
    state = models.IntegerField(default=1, choices=STATE,verbose_name='状态')
    cover = models.CharField(max_length=256, null=False,verbose_name='插图')
    add_time = models.DateTimeField(default=datetime.now(),verbose_name='添加时间')

