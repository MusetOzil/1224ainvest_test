
from rest_framework.viewsets import ModelViewSet
from .models import *
from tools.Serializers import *


class DetailsViws(ModelViewSet):
    queryset = BookDetails.objects.all()
    serializer_class = BookDetailserializers
    pagination_class = MyPageNumberPagination


class updeteAndDeleteview(ModelViewSet):
    queryset = BookDetails.objects.all()
    serializer_class = BookDetailserializers



class postview(ModelViewSet):
    queryset = BookDetails.objects.all()
    serializer_class = BookDetailserializers
