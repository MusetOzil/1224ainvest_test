from django.apps import AppConfig


class MybookConfig(AppConfig):
    name = 'MyBook'
